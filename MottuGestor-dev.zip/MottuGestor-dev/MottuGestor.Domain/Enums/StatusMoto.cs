namespace MottuGestor.Domain.Enums;

public enum StatusMoto
{
    Disponivel = 1,
    EmUso = 2,
    EmManutencao = 3,
    Inativa = 4
}